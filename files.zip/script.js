// Minimal form handler (replace with real backend or Netlify/Forms/TinyLetter)
function handleForm(e){
  e.preventDefault();
  const form = e.target;
  const data = Object.fromEntries(new FormData(form).entries());
  // Basic client-side validation
  if(!data.email || !data.website){ alert('Please fill required fields'); return; }
  // For demo: log and show success
  console.log('Requesting audit', data);
  alert('Thanks! We received your request — check your email for next steps.');
  form.reset();
}
document.getElementById('year').textContent = new Date().getFullYear();